package com.example.appdeprueba

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Environment
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.*
import androidx.core.graphics.createBitmap
import androidx.core.graphics.set

data class QrItem(
    val contenido: String,
    val fecha: Date,
    val tipo: String
)

// Pantalla que muestra el historial de códigos QR generados y leídos por el usuario.
@Composable
fun HistorialScreen(modifier: Modifier = Modifier) {
    var qrItems by remember { mutableStateOf<List<QrItem>>(emptyList()) }
    var selectedQr by remember { mutableStateOf<QrItem?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    val context = LocalContext.current

    // Obtiene y combina los QR generados y leídos del usuario autenticado
    fun fetchQrHistory(userId: String, onResult: (List<QrItem>) -> Unit, onError: (Exception) -> Unit) {
        val db = FirebaseFirestore.getInstance()
        val generadosTask = db.collection("usuarios").document(userId)
            .collection("qr_generados")
            .orderBy("fecha", Query.Direction.DESCENDING)
            .get()
        val lecturasTask = db.collection("usuarios").document(userId)
            .collection("lecturas")
            .orderBy("fecha", Query.Direction.DESCENDING)
            .get()
        generadosTask.addOnSuccessListener { generadosSnapshot ->
            lecturasTask.addOnSuccessListener { lecturasSnapshot ->
                val generados = generadosSnapshot.documents.mapNotNull { doc ->
                    val contenido = doc.getString("contenido") ?: return@mapNotNull null
                    val fecha = doc.getDate("fecha") ?: return@mapNotNull null
                    val tipo = doc.getString("tipo") ?: return@mapNotNull null
                    QrItem(contenido, fecha, tipo)
                }
                val lecturas = lecturasSnapshot.documents.mapNotNull { doc ->
                    val contenido = doc.getString("contenido") ?: return@mapNotNull null
                    val fecha = doc.getDate("fecha") ?: return@mapNotNull null
                    val tipo = doc.getString("tipo") ?: return@mapNotNull null
                    QrItem(contenido, fecha, tipo)
                }
                onResult((generados + lecturas).sortedByDescending { it.fecha })
            }.addOnFailureListener(onError)
        }.addOnFailureListener(onError)
    }

    LaunchedEffect(Unit) {
        val auth = FirebaseAuth.getInstance()
        val currentUser = auth.currentUser
        if (currentUser != null) {
            fetchQrHistory(currentUser.uid,
                onResult = {
                    qrItems = it
                    isLoading = false
                },
                onError = { e ->
                    Log.e("Firestore", "Error al obtener historial", e)
                    Toast.makeText(context, "Error al cargar el historial", Toast.LENGTH_SHORT).show()
                    isLoading = false
                }
            )
        } else {
            Toast.makeText(context, "Debes iniciar sesión para ver el historial", Toast.LENGTH_SHORT).show()
            isLoading = false
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        if (isLoading) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(qrItems) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedQr = item }
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Text(
                                text = item.contenido,
                                style = MaterialTheme.typography.bodyLarge,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tipo: ${item.tipo}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                text = "Fecha: ${item.fecha}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }

    if (selectedQr != null) {
        Dialog(onDismissRequest = { selectedQr = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val qrBitmap = generateQRCode(selectedQr!!.contenido)
                    if (qrBitmap != null) {
                        Image(
                            bitmap = qrBitmap.asImageBitmap(),
                            contentDescription = "Código QR",
                            modifier = Modifier.size(200.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = selectedQr!!.contenido,
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Button(onClick = { selectedQr = null }) {
                            Text("Cerrar")
                        }
                        Button(onClick = {
                            qrBitmap?.let { bitmap ->
                                shareImage(bitmap, context)
                            }
                        }) {
                            Text("Compartir")
                        }
                    }
                }
            }
        }
    }
}

// Genera un código QR a partir del contenido proporcionado.
private fun generateQRCode(content: String): Bitmap? {
    return try {
        val hints = Hashtable<EncodeHintType, Any>().apply {
            put(EncodeHintType.CHARACTER_SET, "UTF-8")
        }

        val qrCodeWriter = QRCodeWriter()
        val bitMatrix = qrCodeWriter.encode(
            content,
            BarcodeFormat.QR_CODE,
            400,
            400,
            hints
        )

        val width = bitMatrix.width
        val height = bitMatrix.height
        val bmp = createBitmap(width, height, Bitmap.Config.RGB_565)
        for (x in 0 until width) {
            for (y in 0 until height) {
                bmp[x, y] = if (bitMatrix[x, y]) Color.BLACK else Color.WHITE
            }
        }
        bmp
    } catch (e: Exception) {
        Log.e("QRCode", "Error generando QR", e)
        null
    }
}

// Comparte la imagen del QR usando un intent de Android.
private fun shareImage(bitmap: Bitmap, context: android.content.Context) {
    val file = saveBitmapToFile(bitmap, context)
    if (file != null) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val shareIntent: Intent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_STREAM, uri)
            type = "image/png"
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        context.startActivity(Intent.createChooser(shareIntent, "Compartir QR"))
    }
}

// Guarda el bitmap del QR como archivo en el almacenamiento externo de la app.
private fun saveBitmapToFile(bitmap: Bitmap, context: android.content.Context): File? {
    val file = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "qr_code.png")
    try {
        val outputStream = FileOutputStream(file)
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
        outputStream.flush()
        outputStream.close()
        return file
    } catch (e: IOException) {
        Log.e("Error", "Error al guardar el archivo", e)
        return null
    }
}