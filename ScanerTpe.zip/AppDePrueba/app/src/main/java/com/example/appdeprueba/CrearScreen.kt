package com.example.appdeprueba

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Environment
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.core.graphics.createBitmap
import androidx.core.graphics.set
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Date
import java.util.Hashtable

// Pantalla para crear códigos QR a partir de texto ingresado por el usuario.
@Composable
fun CrearScreen(modifier: Modifier = Modifier) {
    var text by remember { mutableStateOf("") }
    var qrBitmap by remember { mutableStateOf<Bitmap?>(null) }
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("Texto para QR") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            if (text.isNotBlank()) {
                qrBitmap = generateAndSaveQRCode(text, context)
            } else {
                Toast.makeText(context, "El texto no puede estar vacío", Toast.LENGTH_SHORT).show()
            }
        }) {
            Text("Generar QR")
        }
        Spacer(modifier = Modifier.height(16.dp))

        if (qrBitmap != null) {
            Image(
                bitmap = qrBitmap!!.asImageBitmap(),
                contentDescription = "Código QR generado"
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = {
                shareImage(qrBitmap!!, context)
            }) {
                Text("Compartir QR")
            }
        }
    }
}

// Genera un código QR y lo guarda en Firestore si el usuario está autenticado.
fun generateAndSaveQRCode(text: String, context: android.content.Context): Bitmap? {
    val bitmap = generateQRCodeBitmap(text)
    if (bitmap != null) {
        saveQRToFirestore(text, context)
    } else {
        Toast.makeText(context, "Error al generar el QR", Toast.LENGTH_SHORT).show()
    }
    return bitmap
}

// Genera el bitmap del QR a partir del texto proporcionado.
fun generateQRCodeBitmap(text: String): Bitmap? {
    return try {
        val hints = Hashtable<EncodeHintType, Any>().apply {
            put(EncodeHintType.CHARACTER_SET, "UTF-8")
        }
        val qrCodeWriter = QRCodeWriter()
        val bitMatrix = qrCodeWriter.encode(
            text,
            BarcodeFormat.QR_CODE,
            600,
            600,
            hints
        )
        val width = bitMatrix.width
        val height = bitMatrix.height
        val bmp = createBitmap(width, height, Bitmap.Config.RGB_565)
        for (x in 0 until width) {
            for (y in 0 until height) {
                bmp[x, y] = if (bitMatrix[x, y]) Color.BLACK else Color.WHITE
            }
        }
        bmp
    } catch (e: Exception) {
        Log.e("Error", "Error al generar el QR", e)
        null
    }
}

// Guarda los datos del QR en Firestore si el usuario está autenticado.
fun saveQRToFirestore(text: String, context: android.content.Context) {
    val auth = FirebaseAuth.getInstance()
    val currentUser = auth.currentUser
    if (currentUser != null) {
        val db = FirebaseFirestore.getInstance()
        val qrData = hashMapOf(
            "contenido" to text,
            "fecha" to Date(),
            "tipo" to "QR_GENERADO",
            "userId" to currentUser.uid
        )
        db.collection("usuarios").document(currentUser.uid)
            .collection("qr_generados")
            .add(qrData)
            .addOnSuccessListener { documentReference ->
                Log.d("Firestore", "QR guardado con ID: ${documentReference.id}")
                Toast.makeText(context, "QR guardado exitosamente", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Log.w("Firestore", "Error al guardar el QR", e)
                Toast.makeText(context, "Error al guardar el QR", Toast.LENGTH_SHORT).show()
            }
    } else {
        Toast.makeText(context, "Debes iniciar sesión para guardar QRs", Toast.LENGTH_SHORT).show()
    }
}

// Comparte la imagen del QR generado usando un intent de Android.
private fun shareImage(bitmap: Bitmap, context: android.content.Context) {
    val file = saveBitmapToFile(bitmap, context)
    if (file != null) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val shareIntent: Intent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_STREAM, uri)
            type = "image/png"
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        context.startActivity(Intent.createChooser(shareIntent, "Compartir QR"))
    }
}

// Guarda el bitmap del QR como archivo en el almacenamiento externo de la app.
private fun saveBitmapToFile(bitmap: Bitmap, context: android.content.Context): File? {
    val file = File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "qr_code.png")
    return try {
        val outputStream = FileOutputStream(file)
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
        outputStream.flush()
        outputStream.close()
        file
    } catch (e: IOException) {
        Log.e("Error", "Error al guardar el archivo", e)
        null
    }
}