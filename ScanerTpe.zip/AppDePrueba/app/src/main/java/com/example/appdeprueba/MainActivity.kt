package com.example.appdeprueba

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.appdeprueba.ui.theme.AppDePruebaTheme
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

class MainActivity : ComponentActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var googleSignInClient: GoogleSignInClient
    private val TAG = "MainActivity"
    private val RC_SIGN_IN = 9001
    private val mostrarBotonLoginState = mutableStateOf(false) // Usar val, no var

    // Encapsula el launcher de autenticación Google
    private val signInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            handleSignInResult(task)
        } else {
            Log.w(TAG, "Google sign in failed")
            Toast.makeText(this, "Error en la autenticación", Toast.LENGTH_SHORT).show()
            mostrarBotonLoginState.value = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        auth = FirebaseAuth.getInstance()
        configurarGoogleSignIn()
        verificarUsuarioAutenticado()
        solicitarPermisos(arrayOf(Manifest.permission.CAMERA))
        setContent {
            AppDePruebaTheme {
                var selectedIndex by remember { mutableIntStateOf(0) }
                val mostrarBotonLogin = mostrarBotonLoginState.value
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = { BarraNavegacion(selectedIndex) { selectedIndex = it } }
                ) { innerPadding ->
                    if (mostrarBotonLogin) {
                        BotonLoginGoogle {
                            mostrarBotonLoginState.value = false
                            signIn()
                        }
                    } else {
                        when (selectedIndex) {
                            0 -> LeerScreen(Modifier.padding(innerPadding))
                            1 -> CrearScreen(Modifier.padding(innerPadding))
                            2 -> HistorialScreen(Modifier.padding(innerPadding))
                        }
                    }
                }
            }
        }
    }

    // Configura Google Sign-In
    private fun configurarGoogleSignIn() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)
    }

    // Verifica si el usuario está autenticado, si no, inicia el proceso
    private fun verificarUsuarioAutenticado() {
        if (auth.currentUser == null) signIn()
    }

    // Solicita permisos necesarios
    private fun solicitarPermisos(permisos: Array<String>) {
        val noConcedidos = permisos.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (noConcedidos.isNotEmpty()) {
            val launcher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
            launcher.launch(noConcedidos.toTypedArray())
        }
    }

    // Barra de navegación inferior reutilizable
    @Composable
    private fun BarraNavegacion(selectedIndex: Int, onItemSelected: (Int) -> Unit) {
        NavigationBar {
            NavigationBarItem(
                icon = { Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = "Leer") },
                label = { Text("Leer") },
                selected = selectedIndex == 0,
                onClick = { onItemSelected(0) }
            )
            NavigationBarItem(
                icon = { Icon(Icons.Filled.Create, contentDescription = "Crear") },
                label = { Text("Crear") },
                selected = selectedIndex == 1,
                onClick = { onItemSelected(1) }
            )
            NavigationBarItem(
                icon = { Icon(Icons.Filled.History, contentDescription = "Historial") },
                label = { Text("Historial") },
                selected = selectedIndex == 2,
                onClick = { onItemSelected(2) }
            )
        }
    }

    // Inicia el proceso de autenticación Google
    private fun signIn() {
        val account = GoogleSignIn.getLastSignedInAccount(this)
        if (account != null) {
            firebaseAuthWithGoogle(account.idToken!!)
            return
        }
        val googleApiAvailability = GoogleApiAvailability.getInstance()
        val resultCode = googleApiAvailability.isGooglePlayServicesAvailable(this)
        if (resultCode != ConnectionResult.SUCCESS) {
            if (googleApiAvailability.isUserResolvableError(resultCode)) {
                googleApiAvailability.getErrorDialog(this, resultCode, RC_SIGN_IN)?.show()
            } else {
                Toast.makeText(this, "Este dispositivo no es compatible con Google Play Services", Toast.LENGTH_LONG).show()
            }
            return
        }
        try {
            val signInIntent = googleSignInClient.signInIntent
            signInLauncher.launch(signInIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Error al iniciar el proceso de inicio de sesión", e)
            Toast.makeText(this, "Error al iniciar sesión: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    // Maneja el resultado de autenticación Google
    private fun handleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            val account = completedTask.getResult(ApiException::class.java)
            Log.d(TAG, "firebaseAuthWithGoogle:" + account.id)
            firebaseAuthWithGoogle(account.idToken!!)
        } catch (e: ApiException) {
            val errorMessage = when(e.statusCode) {
                ConnectionResult.SIGN_IN_REQUIRED -> "Se requiere iniciar sesión"
                ConnectionResult.NETWORK_ERROR -> "Error de red. Verifica tu conexión"
                ConnectionResult.INVALID_ACCOUNT -> "Cuenta inválida"
                ConnectionResult.RESOLUTION_REQUIRED -> "Se requiere resolución adicional"
                ConnectionResult.CANCELED -> "Inicio de sesión cancelado"
                else -> "Error en la autenticación: ${e.message}"
            }
            Log.w(TAG, "Google sign in failed: $errorMessage", e)
            Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show()
            mostrarBotonLoginState.value = true
        } catch (e: Exception) {
            Log.e(TAG, "Error inesperado durante el inicio de sesión", e)
            Toast.makeText(this, "Error inesperado: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            mostrarBotonLoginState.value = true
        }
    }

    // Autentica con Firebase usando Google
    private fun firebaseAuthWithGoogle(idToken: String) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    Log.d(TAG, "signInWithCredential:success")
                    auth.currentUser
                    updateUI()
                } else {
                    Log.w(TAG, "signInWithCredential:failure", task.exception)
                    Toast.makeText(this, "Error en la autenticación", Toast.LENGTH_SHORT).show()
                    updateUI()
                }
            }
    }

    // Actualiza la UI según el usuario autenticado
    private fun updateUI() {
        // Puedes actualizar la UI aquí si es necesario
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    AppDePruebaTheme {
        Greeting("Android")
    }
}

@Composable
private fun BotonLoginGoogle(onClick: () -> Unit) {
    androidx.compose.material3.Button(onClick = onClick, modifier = Modifier.fillMaxSize().padding(32.dp)) {
        Text("Iniciar sesión con Google")
    }
}