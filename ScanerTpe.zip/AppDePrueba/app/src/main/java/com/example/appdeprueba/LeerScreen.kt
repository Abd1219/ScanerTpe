package com.example.appdeprueba

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.camera.core.CameraControl
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.Date
import java.util.regex.Pattern

// Pantalla para leer códigos QR usando la cámara. Solicita permisos y muestra el resultado escaneado.
@Composable
fun LeerScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    LocalLifecycleOwner.current
    val clipboardManager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }
    var qrResult by remember { mutableStateOf("") }
    var showDialog by remember { mutableStateOf(false) }
    var isScanning by remember { mutableStateOf(true) }
    var flashEnabled by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted -> hasCameraPermission = granted }
    )

    Box(modifier = modifier.fillMaxSize()) {
        if (hasCameraPermission) {
            CameraPreview(
                onQrCodeScanned = { qr ->
                    if (isScanning) {
                        qrResult = qr
                        showDialog = true
                        isScanning = false
                    }
                },
                isScanning = isScanning,
                flashEnabled = flashEnabled
            )
            IconButton(
                onClick = { flashEnabled = !flashEnabled },
                modifier = Modifier.align(Alignment.TopEnd).padding(16.dp)
            ) {
                Icon(
                    imageVector = if (flashEnabled) Icons.Filled.FlashOn else Icons.Filled.FlashOff,
                    contentDescription = if (flashEnabled) "Apagar flash" else "Encender flash"
                )
            }
        } else {
            Column(modifier = Modifier.fillMaxWidth()) {
                Spacer(modifier = Modifier.weight(1f))
                Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) {
                    Text("Permitir acceso a la cámara")
                }
            }
        }
    }
    if (showDialog) {
        QrDialog(
            qrResult = qrResult,
            onDismiss = {
                showDialog = false
                isScanning = true
            },
            clipboardManager = clipboardManager,
            context = context
        )
    }
}

// Valida si una cadena es una URL
fun isUrlValid(url: String): Boolean {
    val regex = "^(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})([/\\w .-]*)*/?$"
    val pattern = Pattern.compile(regex)
    return pattern.matcher(url).matches()
}

// Diálogo que muestra el resultado del QR y permite copiar, abrir o guardar
@Composable
fun QrDialog(
    qrResult: String,
    onDismiss: () -> Unit,
    clipboardManager: ClipboardManager,
    context: Context
) {
    val auth = FirebaseAuth.getInstance()
    val currentUser = auth.currentUser
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Código QR Detectado") },
        text = {
            Column {
                SelectionContainer {
                    TextField(
                        value = qrResult,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Button(onClick = {
                    val clip = ClipData.newPlainText("QR Code Text", qrResult)
                    clipboardManager.setPrimaryClip(clip)
                    Toast.makeText(context, "Copiado al portapapeles", Toast.LENGTH_SHORT).show()
                }) {
                    Text("Copiar al portapapeles")
                }
                if (isUrlValid(qrResult)) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, qrResult.toUri())
                        context.startActivity(intent)
                    }) {
                        Text("Abrir en el navegador")
                    }
                }
            }
        },
        confirmButton = {
            Row {
                Button(onClick = {
                    if (currentUser != null) {
                        guardarLecturaFirestore(qrResult, currentUser.uid, context)
                    } else {
                        Toast.makeText(context, "Debes iniciar sesión para guardar lecturas", Toast.LENGTH_SHORT).show()
                    }
                    onDismiss()
                }) {
                    Text("Guardar")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = { onDismiss() }) {
                    Text("Cerrar")
                }
            }
        }
    )
}

// Guarda la lectura en Firestore
fun guardarLecturaFirestore(qrResult: String, userId: String, context: Context) {
    val db = FirebaseFirestore.getInstance()
    val lectura = hashMapOf(
        "contenido" to qrResult,
        "fecha" to Date(),
        "tipo" to if (isUrlValid(qrResult)) "URL" else "Texto",
        "userId" to userId
    )
    db.collection("usuarios").document(userId)
        .collection("lecturas")
        .add(lectura)
        .addOnSuccessListener { documentReference ->
            Log.d("Firestore", "Lectura guardada con ID: ${documentReference.id}")
            Toast.makeText(context, "Lectura guardada exitosamente", Toast.LENGTH_SHORT).show()
        }
        .addOnFailureListener { e ->
            Log.w("Firestore", "Error al guardar la lectura", e)
            Toast.makeText(context, "Error al guardar", Toast.LENGTH_SHORT).show()
        }
}

@OptIn(ExperimentalGetImage::class)
@Composable
fun CameraPreview(onQrCodeScanned: (String) -> Unit, isScanning: Boolean, flashEnabled: Boolean) {
    LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var zoomRatio by remember { mutableFloatStateOf(1f) }
    var cameraControlState by remember { mutableStateOf<CameraControl?>(null) }

    @OptIn(ExperimentalGetImage::class)
    fun processImageProxy(imageProxy: ImageProxy, onQrCodeScanned: (String) -> Unit) {
        val mediaImage = imageProxy.image
        if (mediaImage != null) {
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            val options = BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                .build()
            val scanner = BarcodeScanning.getClient(options)
            scanner.process(image)
                .addOnSuccessListener { barcodes ->
                    for (barcode in barcodes) {
                        barcode.rawValue?.let {
                            onQrCodeScanned(it)
                        }
                    }
                }
                .addOnFailureListener { }
                .addOnCompleteListener { imageProxy.close() }
        } else {
            imageProxy.close()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            factory = { ctx ->
                val previewView = PreviewView(ctx)
                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()
                    // Liberar todos los casos de uso antes de volver a enlazar
                    cameraProvider.unbindAll()
                    val preview = androidx.camera.core.Preview.Builder().build().also {
                        it.surfaceProvider = previewView.surfaceProvider
                    }
                    val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                    val imageAnalysis = ImageAnalysis.Builder().build().also {
                        it.setAnalyzer(ContextCompat.getMainExecutor(ctx)) { imageProxy ->
                            if (isScanning) processImageProxy(imageProxy, onQrCodeScanned)
                            else imageProxy.close()
                        }
                    }
                    val camera = cameraProvider.bindToLifecycle(lifecycleOwner, cameraSelector, preview, imageAnalysis)
                    cameraControlState = camera.cameraControl
                    camera.cameraInfo.zoomState.observe(lifecycleOwner) { zoomState ->
                        zoomRatio = zoomState.zoomRatio
                    }
                    camera.cameraControl.enableTorch(flashEnabled)
                }, ContextCompat.getMainExecutor(ctx))
                previewView
            },
            modifier = Modifier.fillMaxSize()
        )
        
        // Efecto para actualizar el estado del flash en tiempo real
        LaunchedEffect(flashEnabled, cameraControlState) {
            cameraControlState?.enableTorch(flashEnabled)
        }
        
        Slider(
            value = zoomRatio,
            onValueChange = {
                zoomRatio = it
                cameraControlState?.setZoomRatio(it)
            },
            valueRange = 1f..5f,
            steps = 3,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
                .fillMaxWidth(0.8f)
        )
    }
    // Fin de archivo optimizado
}

